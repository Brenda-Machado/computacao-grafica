"""
INE5420 - 2024/2
Brenda Silva Machado - 21101954

"""

from dataclasses import dataclass

@dataclass
class PreObject:
    name: str = ""
    color: tuple = (0,0,0)