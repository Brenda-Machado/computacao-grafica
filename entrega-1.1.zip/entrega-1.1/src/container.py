"""
INE5420 - 2024/2
Brenda Silva Machado - 21101954

"""

from dataclasses import dataclass

@dataclass
class Container:
    xMin: int
    yMin: int
    xMax: int
    yMax: int
